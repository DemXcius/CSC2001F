import java.util.*;

class SimulatorOne {
    private static Graph graph = new Graph();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read graph data
        readGraphData(scanner);

        // Read client calls and simulate taxi service
        simulateTaxiService(scanner);

        scanner.close();
    }

    private static void readGraphData(Scanner scanner) {
        // Read number of nodes
        int numberOfNodes = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < numberOfNodes; i++) {
            String[] parts = scanner.nextLine().trim().split("\\s+");
            String sourceNode = parts[0];
            for (int j = 1; j < parts.length-1; j++) {
                String destNode = parts[j];
                double weight = Double.parseDouble(parts[j + 1]);
                graph.addEdge(sourceNode, destNode, weight);
            }
        }
    }

    private static void simulateTaxiService(Scanner scanner) {
        // Read number of clients
        int numberOfClients = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < numberOfClients; i++) {
            String clientNode = scanner.nextLine().trim();
            String shopNode = scanner.nextLine().trim(); // Read shop node
            // Find the nearest taxi and the nearest shop for this client
            processClientCall(clientNode, shopNode);
        }
    }

    private static void processClientCall(String clientNode, String shopNode) {
        // Find the nearest taxi for this client
        graph.dijkstra(clientNode);

        // Output results, passing shop node information
        outputResults(clientNode, shopNode);
    }

    private static void outputResults(String clientNode, String shopNode) {
        Vertex clientVertex = graph.getVertex(clientNode);

        // Output client information
        System.out.println("client " + clientNode);

        // Output taxi details
        List<String> taxiDetails = outputTaxiDetails(clientVertex);

        // Output shop details only if the client can be helped
        if (!taxiDetails.isEmpty()) {
            for (String details : taxiDetails) {
                System.out.println(details);
            }
            System.out.println("shop " + shopNode);
        } else {
            System.out.println("cannot be helped");
        }
    }

    private static List<String> outputTaxiDetails(Vertex clientVertex) {
        List<String> taxiDetails = new ArrayList<>();
        Collection<Vertex> allVertices = graph.getVertexMap().values();

        double minCost = Double.MAX_VALUE;

        // Find minimum cost among taxis
        for (Vertex vertex : allVertices) {
            if (vertex.prev != null && vertex.dist != Graph.INFINITY && vertex.dist < minCost) {
                minCost = vertex.dist;
            }
        }

        // Output details of taxis with minimum cost
        for (Vertex vertex : allVertices) {
            if (vertex.prev != null && vertex.dist == minCost) {
                List<String> pathNodes = new ArrayList<>();
                Vertex currentVertex = vertex;
                while (currentVertex != null) {
                    pathNodes.add(currentVertex.name);
                    currentVertex = currentVertex.prev;
                }
                Collections.reverse(pathNodes);
                taxiDetails.add("taxi " + vertex.name + "\n" + String.join(" ", pathNodes));
            }
        }

        return taxiDetails;
    }
}