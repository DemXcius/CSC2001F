-- 9
SELECT COUNT(DISTINCT productVendor) as numVendors
FROM products;