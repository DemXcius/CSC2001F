-- 1
SELECT * 
FROM productlines;