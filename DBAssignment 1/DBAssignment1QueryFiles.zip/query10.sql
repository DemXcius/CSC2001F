-- 10
SELECT ROUND(MAX(buyPrice*1.7),2) as top
FROM products;