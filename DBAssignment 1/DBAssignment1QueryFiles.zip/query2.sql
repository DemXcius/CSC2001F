-- 2
SELECT city, country
FROM offices
ORDER BY country, city;