import java.util.*;

class SimulatorOne {
    private static Graph graph = new Graph();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read graph data
        readGraphData(scanner);

        // Read client calls and simulate taxi service
        simulateTaxiService(scanner);

        scanner.close();
    }

    private static void readGraphData(Scanner scanner) {
        // Read number of nodes
        System.out.println("Enter the number of nodes:");
        int numberOfNodes = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < numberOfNodes; i++) {
            System.out.println("Enter node data (sourceNode destNode1 weight1 destNode2 weight2 ...):");
            String[] parts = scanner.nextLine().trim().split("\\s+");
            String sourceNode = parts[0];
            for (int j = 1; j < parts.length; j += 2) {
                String destNode = parts[j];
                double weight = Double.parseDouble(parts[j + 1]);
                graph.addEdge(sourceNode, destNode, weight);
            }
        }

    }

    private static void simulateTaxiService(Scanner scanner) {
        // Read number of clients
        System.out.println("Enter the number of shops:");
        int numberOfShops = Integer.parseInt(scanner.nextLine().trim());
        System.out.println("Enter shop node:");
        // might need to make an array
        String[] shopNode = scanner.nextLine().trim().split("\\s+");
        System.out.println("Enter number of clients:");
        int numberOfClients = Integer.parseInt(scanner.nextLine().trim());
        System.out.println("Enter client node:");
        String[] clientNode = scanner.nextLine().trim().split("\\s+");
        ; // Read shop node
        for (int i = 0; i < numberOfShops-1; i++) {
            // Find the nearest taxi and the nearest shop for this client
            processClientCall(clientNode[i], shopNode[i]);
        }
    }

    private static void processClientCall(String clientNode, String shopNode) {
        // Find the nearest taxi for this client
        graph.dijkstra(clientNode);

        // Output results, passing shop node information
        outputResults(clientNode, shopNode);
    }

    private static void outputResults(String clientNode, String shopNode) {
        Vertex clientVertex = graph.getVertex(clientNode);

        // Output client information
        System.out.println("client " + clientNode);

        // Output taxi details
        List<String> taxiDetails = outputTaxiDetails(clientVertex);

        // Output shop details only if the client can be helped
        if (!taxiDetails.isEmpty()) {
            for (String details : taxiDetails) {
                System.out.println(details);
            }
            List<String> shopDetails = outputShopDetails(clientVertex, shopNode);
            for (String details : shopDetails) {
                System.out.println(details);
            }
        } else {
            System.out.println("cannot be helped");
        }
    }

    private static List<String> outputTaxiDetails(Vertex clientVertex) {
        List<String> taxiDetails = new ArrayList<>();
        Collection<Vertex> allVertices = graph.getVertexMap().values();

        // Output details of taxis with minimum cost
        for (Vertex vertex : allVertices) {
            if (vertex.prev != null) {
                List<String> pathNodes = new ArrayList<>();
                Vertex currentVertex = vertex;
                while (currentVertex != null) {
                    pathNodes.add(currentVertex.name);
                    currentVertex = currentVertex.prev;
                }
                taxiDetails.add("taxi " + vertex.name + "\n" + String.join(" ", pathNodes));
            }
        }

        return taxiDetails;
    }

    private static List<String> outputShopDetails(Vertex clientVertex, String shopNode) {
        List<String> shopDetails = new ArrayList<>();
        Vertex shopVertex = graph.getVertex(shopNode);

        // Find the shortest path from the client to the shop
        List<String> pathNodes = new ArrayList<>();
        Vertex currentVertex = clientVertex;
        while (currentVertex != null) {
            pathNodes.add(currentVertex.name);
            currentVertex = currentVertex.prev;
        }

        // If the client can reach the shop, add the path to the shop details
        shopDetails.add("shop " + shopNode + "\n" + String.join(" ", pathNodes) + " " + shopNode);
        

        return shopDetails;
    }
}
