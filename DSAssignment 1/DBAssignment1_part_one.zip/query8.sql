-- 8
SELECT DISTINCT city
FROM offices;
