-- 4
SELECT * FROM productlines LIMIT 1;